<?php

function calculateAge($dateOfBirth) {
    $dob = new DateTime($dateOfBirth);
    
    $currentDate = new DateTime();
    
    $age = $currentDate->diff($dob)->y;
    
    return $age;
}
?>
