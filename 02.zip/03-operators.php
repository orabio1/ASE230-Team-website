<h1>Arithmetic operators</h1>
<?php
$x=1;
$y=2;
echo $x+$y;
echo '<br>';
echo $x-$y;
echo '<br>';
echo $x*$y;
echo '<br>';
echo $x/$y;
echo '<br>';
?>
<h1>Assignment operators</h1>
<?php
$x=1;
$y=2;
$result=$x+$y;
echo $result;
echo '<br>';
$x+=$y;
echo $x;
echo '<br>';
?>
<h1>Comparison operators</h1>
<?php
$x=3;
$y=1;
$result=$x==$y;
var_dump($result);
echo '<br>';
$result=$x===1.0;
var_dump($result);
echo '<br>';
$result=$x!=$y;
var_dump($result);
echo '<br>';
?>
<h1>Increment operators</h1>
<?php
$x=2;
echo $x;
echo '<br>';
echo $x--;
echo '<br>';
echo $x;

?>
<h1>Logical operators</h1>
<?php
$email_is_correct=false;
$password_is_correct=true;
$result=$email_is_correct && $password_is_correct;
var_dump($result);
echo '<br>';
$result=false || false;
var_dump(!$result);
echo '<br>';

?>
<h1>String operators</h1>
<?php
$name='Nicholas';
$age=42;
$string='Hi, my name is '.$name;
$string.=' and I am '.$age;
echo $string;