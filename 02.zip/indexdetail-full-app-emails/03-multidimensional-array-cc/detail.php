<?php
$index=$_GET['index']; // retrieve the index parameter from the query string

$emails = [
    [
        'subject' => 'You\'ve Won 1,000,000 Invisible Coins!',
        'date' => '2023-08-31',
        'sender' => ['name' => 'Totally Real Prince', 'email' => 'totallyrealprince@notascam.com'],
        'recipient' => ['name' => 'John Doe', 'email' => 'johndoe@example.com'],
        'message' => "Dear John Doe,\n\nCongratulations! You have been selected to receive 1,000,000 invisible coins! Please send us your bank details and $100 processing fee to claim your invisible fortune.\n\nRegards,\nTotally Real Prince",
        'cc' => [
            ['name' => 'Another Victim', 'email' => 'anothervictim@example.com'],
            ['name' => 'Curious Cat', 'email' => 'curiouscat@example.com']
        ]
    ],
    [
        'subject' => 'Magic Beans Trade Offer',
        'date' => '2023-08-30',
        'sender' => ['name' => 'Bean Trader Bob', 'email' => 'bob@magicbeans.com'],
        'recipient' => ['name' => 'Jane Smith', 'email' => 'janesmith@example.com'],
        'message' => "Dear Jane Smith,\n\nI am offering a once-in-a-lifetime trade. Your cow for my magic beans. Trust me, they're worth it! I await your positive response.\n\nWarm regards,\nBean Trader Bob",
        'cc' => [
            ['name' => 'Bean Enthusiast Ellie', 'email' => 'ellie@beanlovers.com'],
            ['name' => 'Jack of the Hill', 'email' => 'jackhill@example.com']
        ]
    ],
    [
        'subject' => 'The Ground is Lava! Insurance Offer',
        'date' => '2023-08-29',
        'sender' => ['name' => 'Lava Larry', 'email' => 'larry@lavainsurance.com'],
        'recipient' => ['name' => 'Tom Lively', 'email' => 'tomlively@example.com'],
        'message' => "Dear Tom Lively,\n\nThe ground is turning to lava! But don't worry. For just $500/month, we can insure your feet. Sign up now before it's too hot!\n\nStay cool,\nLava Larry",
        'cc' => [
            ['name' => 'Scared Susan', 'email' => 'susan@example.com'],
            ['name' => 'Hot Feet Pete', 'email' => 'pete@feetfanatics.com']
        ]
    ],
    [
        'subject' => 'Guard Your Belly Button Lint!',
        'date' => '2023-08-28',
        'sender' => ['name' => 'Belly Button Ben', 'email' => 'ben@bellyprotection.com'],
        'recipient' => ['name' => 'Navel Nancy', 'email' => 'nancy@example.com'],
        'message' => "Dear Navel Nancy,\n\nWe've recently noticed an uptick in belly button lint thefts! Protect your lint with our patented Lint Guard for just $19.99.\n\nStay fluffy,\nBelly Button Ben",
        'cc' => [
            ['name' => 'Tummy Tim', 'email' => 'tim@tummytime.com'],
            ['name' => 'Linda Lintlover', 'email' => 'linda@lintlovers.com']
        ]
    ],
    [
        'subject' => 'Extend Your Arm Reach With Our New Gloves!',
        'date' => '2023-08-27',
        'sender' => ['name' => 'Stretchy Steve', 'email' => 'steve@stretchtech.com'],
        'recipient' => ['name' => 'Shorty Sam', 'email' => 'sam@example.com'],
        'message' => "Dear Shorty Sam,\n\nDo you struggle to reach high shelves? Our new Stretchy Gloves can extend your arm reach by 2 whole inches! Grab yours now for just $89.99.\n\nReach for the stars,\nStretchy Steve",
        'cc' => [
            ['name' => 'Tall Tina', 'email' => 'tina@talltales.com'],
            ['name' => 'Handy Hannah', 'email' => 'hannah@handyhelpers.com']
        ]
    ]
];
$email=$emails[$index];
?>
<a href="index.php">Go back</a>
<p>
	<strong><?= $email['sender']['name'] ?> (<?= $email['sender']['email'] ?>)</strong><br />
	<strong>Sent on: <?= $email['date'] ?></strong><br />
	<strong>CC: 
		<?php foreach($email['cc'] as $cc) echo $cc['name'].'( '.$cc['email'].')' ?>
	</strong><br />		
</p>
<h1><?= $email['subject'] ?></h1>
<p><?= $email['message'] ?></p>