<?php
$emails=[
    [
        'subject' => 'You\'ve Won 1,000,000 Invisible Coins!',
        'date' => '2023-08-31',
        'sender' =>'totallyrealprince@notascam.com',
        'message' => "Dear John Doe,\n\nCongratulations! You have been selected to receive 1,000,000 invisible coins! Please send us your bank details and $100 processing fee to claim your invisible fortune.\n\nRegards,\nTotally Real Prince",
    ],
    [
        'subject' => 'Magic Beans Trade Offer',
        'date' => '2023-08-30',
        'sender' =>'bob@magicbeans.com',
        'message' => "Dear Jane Smith,\n\nI am offering a once-in-a-lifetime trade. Your cow for my magic beans. Trust me, they're worth it! I await your positive response.\n\nWarm regards,\nBean Trader Bob",
    ],
    [
        'subject' => 'The Ground is Lava! Insurance Offer',
        'date' => '2023-08-29',
        'sender' =>'larry@lavainsurance.com',
        'message' => "Dear Tom Lively,\n\nThe ground is turning to lava! But don't worry. For just $500/month, we can insure your feet. Sign up now before it's too hot!\n\nStay cool,\nLava Larry",
    ],
    [
        'subject' => 'Guard Your Belly Button Lint!',
        'date' => '2023-08-28',
        'sender' =>'ben@bellyprotection.com',
        'message' => "Dear Navel Nancy,\n\nWe've recently noticed an uptick in belly button lint thefts! Protect your lint with our patented Lint Guard for just $19.99.\n\nStay fluffy,\nBelly Button Ben",
    ],
    [
        'subject' => 'Extend Your Arm Reach With Our New Gloves!',
        'date' => '2023-08-27',
        'sender' =>'steve@stretchtech.com',
        'message' => "Dear Shorty Sam,\n\nDo you struggle to reach high shelves? Our new Stretchy Gloves can extend your arm reach by 2 whole inches! Grab yours now for just $89.99.\n\nReach for the stars,\nStretchy Steve",
    ]
];
?>
	<table border="1" cellpadding="5">
		<tr>
			<th>Date</th>
			<th>From</th>
			<th>Subject</th>
		</tr>
		<?php
			for($i=0;$i<count($emails);$i++){
				$email=$emails[$i];
				?>
				<tr>
					<td>
						<!-- use $i to pass the index of the email to the detail page -->
						<a href="detail.php?index=<?= $i ?>"><?= $email['date'] ?></a>
					</td>
					<td>
						<!-- use $i to pass the index of the email to the detail page -->
						<a href="detail.php?index=<?= $i ?>"><?= $email['sender'] ?></a>
					</td>
					<td>
						<!-- use $i to pass the index of the email to the detail page -->
						<a href="detail.php?index=<?= $i ?>"><?= $email['subject'] ?></a>
					</td>
				</tr>
				<?php
			}
		?>
	</table>