<?php
$index=$_GET['index']; // retrieve the index parameter from the query string
$emails = [
	'You\'ve Won 1,000,000 Invisible Coins!',
	'Magic Beans Trade Offer',
	'The Ground is Lava! Insurance Offer',
	'Guard Your Belly Button Lint!',
	'Extend Your Arm Reach With Our New Gloves!',
];
$email=$emails[$index];
?>
<a href="index.php">Go back</a>
<h1><?= $email ?></h1>