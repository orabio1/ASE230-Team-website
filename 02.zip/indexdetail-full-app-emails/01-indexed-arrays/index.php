<?php
$emails = [
	'You\'ve Won 1,000,000 Invisible Coins!',
	'Magic Beans Trade Offer',
	'The Ground is Lava! Insurance Offer',
	'Guard Your Belly Button Lint!',
	'Extend Your Arm Reach With Our New Gloves!',
];
for($i=0;$i<count($emails);$i++){
	$email=$emails[$i];
	?>
	<div>
		<!-- use $i to pass the index of the email to the detail page -->
		<a href="detail.php?index=<?= $i ?>"><?= $email ?></a>
	</div>
	<hr />
	<?php
}