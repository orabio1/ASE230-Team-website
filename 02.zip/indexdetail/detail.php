<?php
$beatles=[
	[
		'firstname'=>'John',
		'lastname'=>'Lennon',
		'bio'=>'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse ullamcorper, eros ut suscipit porta, mi felis sollicitudin arcu, vel dictum ante massa ac risus. Sed lacus ante, tincidunt malesuada magna vulputate, viverra pellentesque neque. Integer nisl erat, lobortis in erat in, maximus imperdiet sem. Mauris dapibus tortor magna, a accumsan enim posuere sit amet. Ut molestie metus sit amet leo pellentesque, eget cursus nisi iaculis. Proin at malesuada massa, tristique dapibus mi. Curabitur facilisis velit sit amet urna tincidunt suscipit. Phasellus eget ligula nisi. Ut tortor turpis, accumsan vel ex ac, sollicitudin vehicula neque.'
	],
	[
		'firstname'=>'Paul',
		'lastname'=>'McCartney',
		'bio'=>'Nunc et dolor ut erat feugiat ornare quis vel diam. Pellentesque eros massa, finibus sollicitudin metus vitae, faucibus maximus velit. Mauris commodo ligula ac consectetur vestibulum. Nunc eget pretium augue. Fusce vestibulum, mi ut feugiat egestas, lacus ipsum sagittis quam, sed tempus metus turpis nec massa. Donec eget tortor in leo dictum commodo vel id elit. Nam sollicitudin vitae turpis id mattis. Etiam mollis metus id augue congue consequat. Nullam condimentum luctus ullamcorper. Nullam vitae leo condimentum, aliquam nulla in, scelerisque purus. Ut libero est, laoreet sed magna ac, pulvinar porta turpis. Quisque leo eros, placerat id varius quis, bibendum a orci. In eu nisi vel urna dapibus consectetur id at ipsum.'
	],
	[
		'firstname'=>'Ringo',
		'lastname'=>'Starr',
		'bio'=>'Sed placerat, diam vitae porttitor ullamcorper, ex risus finibus neque, eget porta purus diam quis lorem. Aenean elementum et ipsum ut efficitur. Fusce vel cursus nibh. Mauris mollis ultricies lectus id tristique. Nam condimentum lectus ac libero aliquet vehicula. Vestibulum vel placerat ante, non porttitor ligula. Nam ac purus tellus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Phasellus at diam enim. Nulla tellus est, tincidunt quis faucibus ac, molestie non massa. Morbi aliquet augue quis lorem hendrerit pharetra. Integer semper dolor et lorem gravida facilisis.'
	],
	[
		'firstname'=>'George',
		'lastname'=>'Harrison',
		'bio'=>'Curabitur a ultrices nibh. Phasellus est dolor, facilisis sed orci in, facilisis euismod dolor. Aenean nec consectetur nisl. Sed velit velit, elementum volutpat sapien porta, efficitur tempor dolor. Vestibulum posuere egestas quam vitae suscipit. Nam tincidunt nibh eu porttitor ultrices. Aenean a viverra est. Proin enim tortor, semper vel lectus auctor, euismod condimentum odio. In dapibus nisi eu lacus semper, eu vulputate sem efficitur. Vivamus pharetra, ligula at condimentum ultrices, mi purus rhoncus sapien, vel facilisis neque magna malesuada orci. Integer dictum condimentum egestas. Nullam placerat risus sit amet sapien ultrices, vitae feugiat dui porta. Curabitur tortor metus, euismod sed turpis quis, accumsan tempor libero. Nam mollis est id diam ornare, sit amet facilisis velit vestibulum.'
	]
];
$index=$_GET['index'];
?>
<h1><?= $beatles[$index]['firstname'].' '.$beatles[$index]['lastname'] ?></h1>
<p><?= $beatles[$index]['bio'] ?></p>
<a href="index.php">Go back to the list of the members of the band</a>
