<?php
$beatles=[
	[
		'firstname'=>'John',
		'lastname'=>'Lennon',
		'bio'=>''
	],
	[
		'firstname'=>'Paul',
		'lastname'=>'McCartney',
		'bio'=>''
	],
	[
		'firstname'=>'Ringo',
		'lastname'=>'Starr',
		'bio'=>''
	],
	[
		'firstname'=>'George',
		'lastname'=>'Harrison',
		'bio'=>''
	]
];

for($i=0;$i<count($beatles);$i++){
	?>
	<div>
	<h1><?= $beatles[$i]['firstname'].' '.$beatles[$i]['lastname'] ?></h1>
	<a href="detail.php?index=<?= $i ?>">Learn more</a>
	<div>
	<hr />
	<?php
}
?>
