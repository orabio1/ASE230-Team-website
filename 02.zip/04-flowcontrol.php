<h1>IF/ELSE</h1>
<?php
$age=24;
if($age>21){
	echo 'You are allowed in here';
}else{
	echo 'You are not allowed in here';
}
echo '<br>';
echo 'No matter what, this line will be executed';

?>
<h1>NESTED IF</h1>
<?php
$status='canceled';
if($status=='cart'){
	echo 'You might want to proceed to checkout';
}else{
	if($status=='ordered'){
		echo 'You must pay the order before it can be delivered';
	}else{
		if($status=='paid'){
			echo 'We are delivering your order';
		}else{
			if($status=='delivered'){
				echo 'We hope you are happy with the order, otherwise you can return the product';
			}else{
				echo 'Your order was canceled';
			}
		}
	}
}
?>
<h1>ELSEIF</h1>
<?php
$status='paid';
if($status=='cart'){
	echo 'You might want to proceed to checkout';
}elseif($status=='ordered'){
	echo 'You must pay the order before it can be delivered';
}elseif($status=='paid'){
	echo 'We are delivering your order';
}elseif($status=='delivered'){
	echo 'We hope you are happy with the order, otherwise you can return the product';
}else{
	echo 'Your order was canceled';
}
?>
<h1>SWITCH</h1>
<?php
$status='cart';
switch($status){
	case 'cart':
		echo 'You might want to proceed to checkout';
		break;
	case 'ordered':
		echo 'You must pay the order before it can be delivered';
		break;
	case 'paid':
		echo 'We are delivering your order';
		break;
	case 'delivered':
		echo 'We hope you are happy with the order, otherwise you can return the product';
		break;
	default:
		echo 'Your order was canceled';
}
?>
<hr />
<h1>WHILE</h1>
<?php
$x=4;
while($x<5){
	echo 'The value of x is '.$x.'<br>';
	$x++;
}
?>
<hr />
<h1>FOR</h1>
<?php
for($floor=1;$floor<=5;$floor++){
	echo 'You ar on floor '.$floor.'<br>';
}
echo '<hr />';
for($floor=10;$floor>4;$floor--){
	echo 'You ar on floor '.$floor.'<br>';
}
