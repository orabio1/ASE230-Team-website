<?php
$name1='John Lennon';
$name2='Paul McCartney';
$name3='Ringo Starr';
$name4='George Harrison';

?>
<h1><?= $name1 ?></h1>
<h1><?= $name2 ?></h1>
<h1><?= $name3 ?></h1>
<h1><?= $name4 ?></h1>
<hr />
<?php
$name=[
	'John Lennon',
	'Paul McCartney',
	'Ringo Starr',
	'George Harrison'
];

var_dump($name);
echo '<br>';
?>
<?= $name[0]; ?>
<br>
<?= $name[1]; ?>
<br>
<?= $name[2]; ?>
<br>
<?= $name[3]; ?>
<hr />
<?php
$name[]='New element 1';
$name[]='New element 2';
$name[]='New element 3';
$name[]='New element 4';
$name[0]='John Doe';

echo '<br>';
for($index=0;$index<count($name);$index++){
	?>
	<div>
		<strong><?= $name[$index] ?></strong>
	</div>
	<?php
	//$name[$index]='Nobody';
}
var_dump($name);
echo '<br>';
foreach($name as $element){
	?>
	<div>
		<strong><?= $element ?></strong>
	</div>
	<?php
	$element='Nobody';
}
var_dump($name);