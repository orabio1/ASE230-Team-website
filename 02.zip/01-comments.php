<?php
	//Single line comment
	#Single line comment	
	echo 'Something';
	/*
	echo 'Something else';
	*/
?>

<h1><?= 'That\'s all it takes to learn PHP' ?></h1>
<?php
	echo "That's all it takes to learn \"PHP\"";
	
?>
<script>
/*

This is a comment
*/
</script>