<?php

function calculateAge($dateOfBirth) {
    $dob = DateTime::createFromFormat('m-d-y', $dateOfBirth);
    
    $currentDate = new DateTime();
    
    $age = $currentDate->diff($dob)->y;
    
    return $age;
}
?>
