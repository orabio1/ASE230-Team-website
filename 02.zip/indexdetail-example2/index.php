<?php
$dogs=[
	[
		'name'=>'Taco',
		'weight'=>24,
		'gender'=>'male',
		'pictures'=>[
			'taco_01.jpg',
			'taco_02.jpg',
		]
	],
	[
		'name'=>'puma',
		'weight'=>44,
		'gender'=>'male',
		'pictures'=>[
			'puma_01.jpg'
		]
	],
	[
		'name'=>'spot',
		'weight'=>44,
		'gender'=>'male',
		'pictures'=>[
			'spot_01.jpg'
		]
	],
];
for($i=0;$i<count($dogs);$i++){
	if(isset($dogs[$i]['pictures']) && isset($dogs[$i]['pictures'][0])) echo '<img src="assets/'.$dogs[$i]['pictures'][0].'" />';
	?>
	<h1><?= $dogs[$i]['name'] ?></h1>
	<p><?= $dogs[$i]['gender'] ?></p>
	<a href="detail.php?index=<?= $i ?>">See dog</a>
	<hr />
	<?php
}