<?php
$dogs=[
	[
		'name'=>'Taco',
		'weight'=>24,
		'gender'=>'male',
		'pictures'=>[
			'taco_01.jpg',
			'taco_02.jpg',
		]
	],
	[
		'name'=>'puma',
		'weight'=>44,
		'gender'=>'male',
		'pictures'=>[
			'puma_01.jpg'
		]
	],
	[
		'name'=>'spot',
		'weight'=>44,
		'gender'=>'male',
		'pictures'=>[
			'spot_01.jpg'
		]
	],
];

?>
<h1><?= $dogs[$_GET['index']]['name'] ?></h1>
<p><?= $dogs[$_GET['index']]['gender'] ?></p>
<?php
if(isset($dogs[$_GET['index']]['pictures'])){
	for($i=0;$i<count($dogs[$_GET['index']]['pictures']);$i++){
		echo '<img src="assets/'.$dogs[$_GET['index']]['pictures'][$i].'" />';
	}
}
?>
<hr />
<a href="index.php">Back to the index page</a>