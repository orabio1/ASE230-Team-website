<?php
	$name='Nicholas';
	$age=42.5;
	$happy=true;
	$whatever=$name;
	$WHATEVER=$age;
	$WHATEVER=$happy;
?>


<h1><?= $name ?></h1>
<h2><?= $age ?></h2>
<h3><?php echo $happy ?></h3>
<hr />
<h1><?php echo $whatever ?></h1>
<h1><?= $WHATEVER ?></h1>
<hr/>
<h1><?php echo $name ?></h1>
<h1><?php echo '$name' ?></h1>
<h1><?php echo "My name is $name" ?></h1>
<h1><?php echo 'My name is '.$name.', and I am '.$age ?></h1>
<?php

var_dump($whatever);

?>