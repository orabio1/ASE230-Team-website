<?php
$beatles=[
	'John Lennon',
	'Paul McCartney',
	'Ringo Starr',
	'George Harrison'
];
var_dump($beatles);
?>
<hr />
<?php
print_r($beatles);
?>
<hr />
<?php
$musician=[
	'firstname'=>'John',
	'lastname'=>'Lennon',
	'age'=>30
];
$musician['lastname']='Doe';
$musician['city']='Liverpool';
echo $musician['firstname'].' '.$musician['lastname'].' from '.$musician['city'];

?>
<hr />
<?php
foreach($musician as $key=>$value){
	echo $key.': '.$value.'<br>';
}