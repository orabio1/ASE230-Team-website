<?php
$beatles=[
	'John Lennon',
	'Paul McCartney',
	'Ringo Starr',
	'George Harrison'
];
for($i=0;$i<count($beatles);$i++){
	echo '<h1>'.$beatles[$i].'</h1>';
}

?>
<hr />
<?php
$beatles=[
	['John','Lennon'],
	['Paul','McCartney'],
	['Ringo','Starr'],
	['George','Harrison']
];
for($i=0;$i<count($beatles);$i++){
	echo '<h1>'.$beatles[$i][0].' '.$beatles[$i][1].'</h1>';
}
?>
<hr />
<?php
$beatles=[
	[
		'firstname'=>'John',
		'lastname'=>'Lennon',
		'luckynumbers'=>[2,15]
	],
	[
		'firstname'=>'Paul',
		'lastname'=>'McCartney',
		'luckynumbers'=>[9,1,98]
	],
	[
		'firstname'=>'Ringo',
		'lastname'=>'Starr',
		'luckynumbers'=>[5]
	],
	[
		'firstname'=>'George',
		'lastname'=>'Harrison',
		'luckynumbers'=>[1,99,42]
	]
];
$beatles[0]['lastname']='Doe';
$beatles[0]['luckynumbers'][]=2000;
$beatles[0]['luckynumbers'][0]=1;
for($i=0;$i<count($beatles);$i++){
	echo '<h1>'.$beatles[$i]['firstname'].' '.$beatles[$i]['lastname'].'</h1>';
	for($j=0;$j<count($beatles[$i]['luckynumbers']);$j++){
		echo $beatles[$i]['luckynumbers'][$j].';';
	}
	echo '<hr />';
}